(() => {
    "use strict";
    // One script for Safari (SafariServices messages) and the Zen/Firefox and
    // Chromium add-ons (WebExtension messages): only the bridge differs.
    const webextension = globalThis.browser ?? globalThis.chrome;
    const bridge = webextension?.runtime?.id ? webextensionBridge(webextension)
        : typeof safari !== "undefined" ? safariBridge() : null;
    // Only the top frame handles requests; it may inspect same-origin frames.
    if (window.top !== window || !bridge) return;
    let plan = null;
    const requestPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const otpPattern = /(?:^|[^a-z])(?:otp|totp|2fa|mfa|otc)(?:[^a-z]|$)|otp(?:code|token)|one[\s_-]*time[\s_-]*(?:code|password)|(?:verification|security|authentication|authentification|authenticator|auth|login|challenge|verif(?:ication)?|securite)[\s_-]*code|code[\s_-]*(?:de[\s_-]*)?(?:verification|security|authentication|authentification|auth|verif(?:ication)?|securite)|passcode|mot de passe a usage unique|two[\s_-]*factor|deux facteurs|code.{0,40}(?:authenticator|authentificateur)/;
    const excludedPattern = /postal|zipcode|zip-code|coupon|promo|gift|discount|cvv|cvc|credit|card.number|iban|recovery|backup|recuperation|secours|api[\s_-]*(?:key|token)|access[\s_-]*token|client[\s_-]*secret/;
    const normalize = value => String(value || "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
    const description = input => normalize([
        input.name, input.id, input.getAttribute("aria-label"), input.getAttribute("placeholder"),
        ...Array.from(input.labels || [], label => label.textContent),
        ...(input.getAttribute("aria-labelledby") || "").split(/\s+/).map(id => input.ownerDocument.getElementById(id)?.textContent)
    ].join(" "));
    const visibleElement = element => {
        try {
            if (!element.isConnected || element.closest('[hidden], [inert], [aria-hidden="true"]')) return false;
            const host = element.getRootNode().host;
            if (host && !visibleElement(host)) return false;
            const owner = element.ownerDocument.defaultView;
            if (!owner) return false;
            if (owner !== window) {
                const frame = owner.frameElement;
                if (!frame || frame.contentDocument !== element.ownerDocument || !visibleElement(frame)) return false;
            }
            if (typeof element.checkVisibility === "function" && !element.checkVisibility({checkOpacity: true, checkVisibilityCSS: true})) return false;
            const style = owner.getComputedStyle(element);
            const rect = element.getBoundingClientRect();
            return style.visibility !== "hidden" && style.display !== "none" && style.opacity !== "0" && rect.width > 0 && rect.height > 0;
        } catch (_) { return false; }
    };
    const visible = input => !input.disabled && !input.matches(":disabled") && !input.readOnly && ["text", "tel", "number"].includes(input.type) && visibleElement(input);
    const marked = input => !excludedPattern.test(description(input)) &&
        (input.autocomplete.split(/\s+/).includes("one-time-code") || otpPattern.test(description(input)));

    function inputsIn(root, results, depth = 0, roots = null) {
        if (depth > 8 || results.length > 200) return;
        roots?.push(root);
        for (const input of root.querySelectorAll("input")) if (visible(input)) results.push(input);
        for (const node of root.querySelectorAll("*")) if (node.shadowRoot) inputsIn(node.shadowRoot, results, depth + 1, roots);
        for (const frame of root.querySelectorAll("iframe")) {
            try {
                // contentDocument is unavailable for foreign/opaque origins.
                if (visibleElement(frame) && frame.contentDocument) inputsIn(frame.contentDocument, results, depth + 1, roots);
            } catch (_) { /* Cross-origin frames never receive codes. */ }
        }
    }

    function chooseTargets(digits, knownInputs = null) {
        const inputs = knownInputs || [];
        if (!knownInputs) inputsIn(document, inputs);
        if (inputs.length > 200) return {status: "no-field"};
        const candidates = inputs.filter(input => input.maxLength !== 1 && marked(input) &&
            (input.maxLength < 0 || input.maxLength >= digits)).map(input => [input]);
        const groups = new Map();
        for (const input of inputs) {
            if (input.maxLength !== 1 || excludedPattern.test(description(input))) continue;
            const group = input.closest('fieldset, [role="group"], [data-otp-group]') || input.form || input.parentElement || input.getRootNode();
            if (!groups.has(group)) groups.set(group, []);
            groups.get(group).push(input);
        }
        for (const [group, cells] of groups) {
            const context = normalize([group.id, group.getAttribute?.("aria-label"), group.querySelector("legend")?.textContent, group.textContent?.slice(0, 600)].join(" "));
            const numeric = cells.every(input => input.inputMode === "numeric" || input.type === "number" || input.getAttribute("pattern") === "[0-9]");
            if (cells.length === digits && (cells.some(marked) || (numeric && otpPattern.test(context) && !excludedPattern.test(context)))) candidates.push(cells);
        }
        const focused = candidates.filter(cells => cells.some(input => input === input.ownerDocument.activeElement || input === input.getRootNode().activeElement));
        if (focused.length === 1) return {status: "ready", targets: focused[0]};
        if (candidates.length === 1) return {status: "ready", targets: candidates[0]};
        return {status: candidates.length ? "ambiguous" : "no-field"};
    }

    function reply(data, stage, status, extra = {}) {
        return {requestID: data.requestID, origin: data.origin, stage, status, ...extra};
    }

    let watching = false;
    let detectionTimer = null;
    let fallbackTimer = null;
    let lastSignature = null;
    const observer = new MutationObserver(() => scheduleDetection());
    const observationOptions = {subtree: true, childList: true, characterData: true, attributes: true,
        attributeFilter: ["autocomplete", "name", "id", "aria-label", "aria-labelledby", "aria-hidden", "placeholder",
                          "type", "hidden", "disabled", "readonly", "inert", "style", "class", "maxlength", "inputmode", "pattern"]};

    function detectedDigits() {
        const inputs = [], roots = [];
        if (!document.hidden) inputsIn(document, inputs, 0, roots);
        // Share one DOM traversal across all supported TOTP lengths. No input value is read.
        const digits = [6, 7, 8].filter(length => chooseTargets(length, inputs).status === "ready");
        if (watching) {
            observer.disconnect();
            for (const root of roots) observer.observe(root, observationOptions);
        }
        return digits;
    }

    function signature(digits) { return location.href + ":" + digits.join(","); }
    function checkPresence() {
        clearTimeout(detectionTimer);
        detectionTimer = null;
        if (!watching) return;
        const current = signature(detectedDigits());
        if (lastSignature !== null && lastSignature !== current) {
            // This is only an invalidation signal; native code rechecks the active page.
            bridge.notify("dmx-otp-fields-changed");
        }
        lastSignature = current;
    }
    function scheduleDetection() {
        if (watching && detectionTimer === null) detectionTimer = setTimeout(checkPresence, 150);
    }
    function updateFallback() {
        clearInterval(fallbackTimer);
        fallbackTimer = watching && !document.hidden ? setInterval(scheduleDetection, 1000) : null;
    }
    function stopDetection() {
        watching = false;
        observer.disconnect();
        clearTimeout(detectionTimer);
        detectionTimer = null;
        clearInterval(fallbackTimer);
        fallbackTimer = null;
        lastSignature = null;
    }
    document.addEventListener("visibilitychange", () => {
        if (!watching) return;
        updateFallback();
        checkPresence();
    });
    for (const name of ["load", "focusin", "focusout"]) document.addEventListener(name, scheduleDetection, true);
    for (const name of ["resize", "pageshow", "popstate", "hashchange"]) window.addEventListener(name, scheduleDetection);
    window.addEventListener("pagehide", stopDetection);

    bridge.listen(handle);

    /** WebExtension: requests and replies through runtime messages, answered with sendResponse. */
    function webextensionBridge(api) {
        return {
            listen(handler) {
                // The background alone can message this script.
                api.runtime.onMessage.addListener((message, sender, sendResponse) => {
                    if (sender.id !== api.runtime.id || sender.tab || !message || typeof message.name !== "string") return;
                    const result = handler(message.name, message);
                    if (result) sendResponse(result);
                });
            },
            notify(name) { api.runtime.sendMessage({name}).catch(() => {}); },
            ask(stage, data) {
                return Promise.race([
                    api.runtime.sendMessage({name: "dmx-otp-inline", stage, ...data}).catch(() => null),
                    new Promise(resolve => setTimeout(() => resolve(null), 4000))
                ]);
            }
        };
    }

    /** Safari: native requests arrive as page messages; answers go back by request ID. */
    function safariBridge() {
        let handler = null;
        const pending = new Map();
        safari.self.addEventListener("message", event => {
            if (event.name === "dmx-otp-inline-result") {
                const resolve = pending.get(event.message?.requestID);
                if (resolve) { pending.delete(event.message.requestID); resolve(event.message); }
                return;
            }
            const result = handler?.(event.name, event.message || {});
            if (result) safari.extension.dispatchMessage("dmx-otp-result", result);
        });
        return {
            listen(next) { handler = next; },
            notify(name) { safari.extension.dispatchMessage(name, {}); },
            ask(stage, data) {
                const requestID = uuid();
                return new Promise(resolve => {
                    pending.set(requestID, resolve);
                    safari.extension.dispatchMessage("dmx-otp-inline", {requestID, origin: location.origin, stage, ...data});
                    setTimeout(() => { if (pending.delete(requestID)) resolve(null); }, 4000);
                });
            }
        };
    }

    // crypto.randomUUID only exists on HTTPS pages.
    function uuid() {
        const bytes = crypto.getRandomValues(new Uint8Array(16));
        bytes[6] = (bytes[6] & 0x0f) | 0x40;
        bytes[8] = (bytes[8] & 0x3f) | 0x80;
        const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("");
        return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
    }

    function handle(name, data) {
        if (name === "dmx-otp-stop-detect") { stopDetection(); return null; }
        if (!["dmx-otp-detect", "dmx-otp-probe", "dmx-otp-fill"].includes(name)) return null;
        if (typeof data.requestID !== "string" || !requestPattern.test(data.requestID) || data.origin !== location.origin) return null;
        if (name === "dmx-otp-detect") {
            watching = true;
            const digits = detectedDigits();
            lastSignature = signature(digits);
            updateFallback();
            return reply(data, "detect", digits.length ? "ready" : "no-field", {availableDigits: digits});
        }
        if (name === "dmx-otp-probe") {
            plan = null;
            if (!Number.isInteger(data.digits) || data.digits < 6 || data.digits > 8) return null;
            const result = chooseTargets(data.digits);
            if (result.status === "ready") {
                plan = {id: data.requestID, url: location.href, digits: data.digits, targets: result.targets, until: Date.now() + 2000};
                const id = data.requestID;
                setTimeout(() => { if (plan?.id === id) plan = null; }, 2000);
            }
            return reply(data, "probe", result.status);
        }
        const current = plan;
        plan = null;
        const selection = current ? chooseTargets(current.digits) : null;
        if (!current || current.id !== data.requestID || current.url !== location.href || current.until < Date.now() ||
            selection.status !== "ready" || selection.targets.length !== current.targets.length ||
            !selection.targets.every((input, index) => input === current.targets[index])) {
            return reply(data, "fill", "changed");
        }
        if (typeof data.code !== "string" || !/^[0-9]{6,8}$/.test(data.code) || data.code.length !== current.digits ||
            !Number.isFinite(data.validUntil) || data.validUntil <= Date.now() || data.validUntil > Date.now() + 300000) {
            return reply(data, "fill", "expired");
        }
        try {
            current.targets.forEach((input, index) => {
                const value = current.targets.length === 1 ? data.code : data.code[index];
                const owner = input.ownerDocument.defaultView;
                // The native setter also updates controlled React/Vue forms.
                Object.getOwnPropertyDescriptor(owner.HTMLInputElement.prototype, "value").set.call(input, value);
                input.dispatchEvent(new owner.Event("input", {bubbles: true, composed: true}));
                input.dispatchEvent(new owner.Event("change", {bubbles: true, composed: true}));
            });
            const filled = current.targets.every((input, index) => input.isConnected && input.value === (current.targets.length === 1 ? data.code : data.code[index]));
            // No button is clicked and no form submission is requested.
            return reply(data, "fill", filled ? "filled" : "failed");
        } catch (_) { return reply(data, "fill", "failed"); }
    }

    // Suggestion under a focused OTP field, like macOS AutoFill. It lives in a
    // closed shadow root the page can neither read nor restyle, reacts only to
    // trusted clicks and keys, and asks for codes only once the user picks it.
    const dismissed = new WeakSet();
    let suggestion = null;
    let suggestionToken = 0;

    function deepActiveElement() {
        let active = document.activeElement;
        while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
        return active;
    }

    /** Code lengths whose field (or group of cells) contains this input, and those targets. */
    function fieldOf(input) {
        const inputs = [];
        inputsIn(document, inputs);
        const fields = [6, 7, 8].map(digits => ({digits, result: chooseTargets(digits, inputs)}))
            .filter(({result}) => result.status === "ready" && result.targets.includes(input));
        return fields.length ? {digits: fields.map(field => field.digits), targets: fields[0].result.targets} : null;
    }

    document.addEventListener("focusin", event => {
        const input = event.composedPath()[0];
        if (!event.isTrusted || input?.tagName !== "INPUT" || input.ownerDocument !== document) return;
        if (suggestion?.targets.includes(input)) return;
        hideSuggestion();
        if (dismissed.has(input) || input.value !== "") return;
        const field = fieldOf(input);
        if (!field || field.targets.some(target => dismissed.has(target))) return;
        const token = ++suggestionToken;
        bridge.ask("info", {digits: field.digits}).then(info => {
            if (token !== suggestionToken || deepActiveElement() !== input || info?.status !== "ok") return;
            const issuers = Array.isArray(info.issuers) ? info.issuers.filter(issuer => typeof issuer === "string").slice(0, 8) : [];
            if (issuers.length) showSuggestion(input, field, issuers);
        });
    }, true);

    document.addEventListener("focusout", event => {
        if (!suggestion || !event.isTrusted) return;
        // Focus moving into the suggestion keeps it open.
        setTimeout(() => {
            if (suggestion && document.activeElement !== suggestion.host && !suggestion.targets.includes(deepActiveElement())) hideSuggestion();
        }, 0);
    }, true);

    document.addEventListener("keydown", event => {
        if (!suggestion || !event.isTrusted) return;
        if (event.key === "Escape") {
            dismissSuggestion();
        } else if (event.key === "ArrowDown" && suggestion.targets.includes(deepActiveElement())) {
            event.preventDefault();
            suggestion.root.querySelector("button")?.focus();
        }
    }, true);

    document.addEventListener("input", event => {
        // The user typing the code themselves; a fill dispatches untrusted events.
        if (event.isTrusted && suggestion?.targets.includes(event.composedPath()[0])) hideSuggestion();
    }, true);

    document.addEventListener("pointerdown", event => {
        if (suggestion && event.isTrusted && !event.composedPath().includes(suggestion.host) &&
            !suggestion.targets.includes(event.composedPath()[0])) hideSuggestion();
    }, true);

    for (const name of ["scroll", "resize"]) window.addEventListener(name, () => placeSuggestion(), {capture: true, passive: true});
    window.addEventListener("pagehide", () => hideSuggestion());

    function hideSuggestion() {
        suggestionToken++;
        suggestion?.host.remove();
        suggestion = null;
    }

    function dismissSuggestion() {
        if (!suggestion) return;
        const {input, targets} = suggestion;
        targets.forEach(target => dismissed.add(target));
        hideSuggestion();
        input.focus();
    }

    function placeSuggestion() {
        if (!suggestion) return;
        const {host, targets} = suggestion;
        if (!targets.every(target => target.isConnected && visible(target))) { hideSuggestion(); return; }
        const rects = targets.map(target => target.getBoundingClientRect());
        const left = Math.min(...rects.map(rect => rect.left));
        const top = Math.min(...rects.map(rect => rect.top));
        const bottom = Math.max(...rects.map(rect => rect.bottom));
        const width = Math.min(320, Math.max(240, Math.max(...rects.map(rect => rect.right)) - left));
        const height = host.getBoundingClientRect().height || 56;
        const below = bottom + 6 + height <= window.innerHeight || top - 6 - height < 0;
        host.style.setProperty("width", `${width}px`, "important");
        host.style.setProperty("left", `${Math.max(8, Math.min(left, window.innerWidth - width - 8))}px`, "important");
        host.style.setProperty("top", `${below ? bottom + 6 : top - 6 - height}px`, "important");
    }

    function showSuggestion(input, field, issuers) {
        hideSuggestion();
        const host = document.createElement("dmx-otp-suggestion");
        host.style.cssText = "all: initial !important; position: fixed !important; z-index: 2147483647 !important; display: block !important;";
        const root = host.attachShadow({mode: "closed"});
        const css = `
            :host { color-scheme: light dark; }
            .card { box-sizing: border-box; width: 100%; padding: 4px; border-radius: 10px; font: 13px/1.3 -apple-system, BlinkMacSystemFont, system-ui, sans-serif;
                    color: #1d1d1f; background: rgba(246, 246, 246, 0.94); border: 0.5px solid rgba(0, 0, 0, 0.16);
                    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.18); -webkit-backdrop-filter: blur(20px); backdrop-filter: blur(20px); }
            button { all: unset; box-sizing: border-box; display: flex; align-items: center; gap: 9px; width: 100%; padding: 6px 8px; border-radius: 6px; cursor: default; }
            button:hover, button:focus-visible { background: #3f8f9b; color: #fff; }
            button:hover small, button:focus-visible small { color: rgba(255, 255, 255, 0.82); }
            .icon { flex: none; display: grid; place-items: center; width: 26px; height: 26px; border-radius: 6px; background: #3f8f9b; color: #fff; }
            .text { display: grid; min-width: 0; }
            b, small { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
            b { font-weight: 600; }
            small { font-size: 11px; color: #6e6e73; }
            .note { padding: 6px 8px; font-size: 11px; color: #6e6e73; }
            @media (prefers-color-scheme: dark) {
                .card { color: #f2f2f2; background: rgba(40, 40, 42, 0.94); border-color: rgba(255, 255, 255, 0.14); }
                small, .note { color: #a1a1a6; }
            }`;
        // A constructed sheet is not an inline style, which a strict page CSP may block.
        try {
            const sheet = new CSSStyleSheet();
            sheet.replaceSync(css);
            root.adoptedStyleSheets = [sheet];
        } catch (_) {
            const style = document.createElement("style");
            style.textContent = css;
            root.append(style);
        }
        const card = document.createElement("div");
        card.className = "card";
        card.setAttribute("role", "menu");
        card.setAttribute("aria-label", "Codes DmxUtilities");
        root.append(card);
        // Keeps the focus in the field while the suggestion is clicked.
        root.addEventListener("mousedown", event => event.preventDefault());
        root.addEventListener("keydown", event => {
            if (!event.isTrusted) return;
            const buttons = [...root.querySelectorAll("button")];
            const index = buttons.indexOf(root.activeElement);
            if (event.key === "ArrowDown" || event.key === "ArrowUp") {
                event.preventDefault();
                buttons[(index + (event.key === "ArrowDown" ? 1 : buttons.length - 1)) % buttons.length]?.focus();
            } else if (event.key === "Escape") {
                event.preventDefault();
                dismissSuggestion();
            }
        });
        suggestion = {host, root, card, input, targets: field.targets, digits: field.digits, busy: false};
        renderRows([{title: issuers.length === 1 ? issuers[0] : `${issuers.length} comptes`,
                     detail: issuers.length === 1 ? "Remplir le code · DmxUtilities" : "Choisir un code · DmxUtilities"}]);
        document.documentElement.append(host);
        placeSuggestion();
    }

    function renderRows(rows, note = "") {
        const {card} = suggestion;
        card.replaceChildren();
        for (const row of rows) {
            const button = document.createElement("button");
            button.type = "button";
            button.setAttribute("role", "menuitem");
            const icon = document.createElement("span");
            icon.className = "icon";
            icon.append(keyIcon());
            const text = document.createElement("span");
            text.className = "text";
            const title = document.createElement("b");
            title.textContent = row.title;
            const detail = document.createElement("small");
            detail.textContent = row.detail;
            text.append(title, detail);
            button.append(icon, text);
            button.addEventListener("click", event => { if (event.isTrusted) pick(row.id); });
            card.append(button);
        }
        if (note) {
            const message = document.createElement("div");
            message.className = "note";
            message.textContent = note;
            card.append(message);
        }
        placeSuggestion();
    }

    // Built node by node: pages enforcing Trusted Types reject innerHTML.
    function keyIcon() {
        const ns = "http://www.w3.org/2000/svg";
        const svg = document.createElementNS(ns, "svg");
        for (const [name, value] of Object.entries({width: 15, height: 15, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor",
            "stroke-width": 2.2, "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true"})) svg.setAttribute(name, value);
        const circle = document.createElementNS(ns, "circle");
        circle.setAttribute("cx", 8); circle.setAttribute("cy", 15); circle.setAttribute("r", 4);
        const path = document.createElementNS(ns, "path");
        path.setAttribute("d", "m10.8 12.2 8.7-8.7M17 6l2.5 2.5M14.5 8.5 17 11");
        svg.append(circle, path);
        return svg;
    }

    const failures = {
        unreachable: "Ouvrez DmxUtilities pour remplir le code.",
        unavailable: "Code indisponible. Réessayez dans un instant.",
        timeout: "Rechargez la page, puis réessayez.",
        "no-field": "Champ introuvable : utilisez le panneau DmxUtilities.",
        ambiguous: "Plusieurs champs : sélectionnez celui à remplir.",
        changed: "La page a changé. Réessayez.",
        expired: "Code expiré. Réessayez."
    };

    async function pick(id) {
        if (!suggestion || suggestion.busy) return;
        const current = suggestion;
        current.busy = true;
        current.card.querySelectorAll("small").forEach(detail => { detail.textContent = "Remplissage…"; });
        const result = await bridge.ask("fill", id ? {digits: current.digits, id} : {digits: current.digits});
        if (suggestion !== current) return;
        current.busy = false;
        if (result?.status === "filled") {
            current.card.querySelectorAll("small").forEach(detail => { detail.textContent = "Rempli ✓"; });
            current.targets.forEach(target => dismissed.add(target));
            setTimeout(() => { if (suggestion === current) hideSuggestion(); }, 900);
        } else if (result?.status === "choose" && Array.isArray(result.accounts) && result.accounts.length) {
            renderRows(result.accounts.slice(0, 8).map(account => ({
                id: String(account.id), title: String(account.issuer || "Compte"), detail: String(account.accountName || "")
            })));
            current.root.querySelector("button")?.focus();
        } else {
            renderRows([], failures[result?.status] || "Remplissage impossible. Utilisez le panneau DmxUtilities.");
        }
    }
})();
